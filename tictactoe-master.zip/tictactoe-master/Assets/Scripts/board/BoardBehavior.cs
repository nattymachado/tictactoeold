﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum PlayerType { AIPlayer, HumanPlayer };


public class BoardBehavior : MonoBehaviour {


    private BoardConfiguration _configuration = null;
    private SpriteRenderer[] positionsRenderer = null;
    private PlayerType currentPlayer;
    
    public Sprite Circle = null;
    public Sprite Cross = null;


    // Use this for initialization
    private void Start () {

        _configuration = BoardConfigurationGetter.getConfigurationObject();
        Board board = new Board();
        _configuration.SetBoard(board);
        initializeBoardPositions();
        board.InitializePositions();
        currentPlayer = Player1;
    }

    private void initializeBoardPositions()
    {
        positionsRenderer = GetComponentsInChildren<SpriteRenderer>();

        for (int position=1; position<positionsRenderer.Length; position++)
        {
            positionsRenderer[position].sprite = null;
        }
    }

    // Update is called once per frame
    public void ClickBehavior(int positionId, int line, int column)
    {
        Board board = _configuration.GetBoard();
        if (currentPlayer ==  Player1)
        {
            positionsRenderer[positionId].sprite = Cross;
            board.SetPosition(line, column, Player1);
            currentPlayer = Player2;
        } else
        {
            positionsRenderer[positionId].sprite = Circle;
            board.SetPosition(line, column, currentPlayer);
            currentPlayer = 1;
        }
        
        if (IsGameEnded())
        {
            Debug.Log("Jogo terminou");
        }
    }

    private bool IsGameEnded()
    {
        if (checkGameEndingColumns() == 0)
        {
            if (checkGameEndingLines() == 0)
            {
                if (checkGameEndingDiagonal() != 0) return true;
            } else return true;
        } else return true;
        return false;
    }

    private int checkGameEndingColumns()
    {
        Board board = _configuration.GetBoard();
        for (int column =0; column < 3; column++)
        {
            if ((board.GetPosition(0, column) != 0) && (board.GetPosition(0, column) == board.GetPosition(1, column)) && (board.GetPosition(1, column) == board.GetPosition(2, column)) )
            {
                return board.GetPosition(0, column);
            }
        }
        return 0;
    }

    private int checkGameEndingDiagonal()
    {
        Board board = _configuration.GetBoard();
        if ((board.GetPosition(0, 0) != 0) && (board.GetPosition(0, 0) == board.GetPosition(1, 1)) && (board.GetPosition(1, 1) == board.GetPosition(2, 2)))
        {
            return board.GetPosition(0, 0);
        } else if ((board.GetPosition(0, 2) != 0) && (board.GetPosition(0, 2) == board.GetPosition(1, 1)) && (board.GetPosition(1, 1) == board.GetPosition(2, 1)))
        {
            return board.GetPosition(0, 2);
        }
        return 0;
    }

    private int checkGameEndingLines()
    {
        Board board = _configuration.GetBoard();
        for (int line = 0; line < 3; line++)
        {

            if ((board.GetPosition(line, 0) != 0) && (board.GetPosition(line, 0) == board.GetPosition(line, 1)) && (board.GetPosition(line, 1) == board.GetPosition(line, 2)))
            {
                return board.GetPosition(line, 0);
            }
        }
        return 0;
    }

    // Update is called once per frame
    private void Update () {
		
	}
}
