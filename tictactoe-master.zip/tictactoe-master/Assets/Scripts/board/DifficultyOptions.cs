﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DifficultyOptions  {

    public enum Options { Easy, Medium, Hard };
}
