﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Board {

    private int[,] _positions;


    public int GetPosition(int line, int column)
    {
        Debug.Log("Getting position");
        return _positions[line, column];
    }

    public void SetPosition(int line, int column,  value)
    {
        Debug.Log("Setting position");
        Debug.Log(line);
        Debug.Log(column);
        Debug.Log(_positions);
        _positions[line, column] = value;
    }

    public Dictionary<string, int> GetBoardDimensions()
    { 
    
        Debug.Log("Tô aui");
        Dictionary<string, int> Dimensions = new Dictionary<string, int>();
        Dimensions["lines"] = 3;
        Dimensions["columns"] = 3;
        return Dimensions;
    }


    public void InitializePositions()
    {
        Debug.Log("Init");
        _positions = new int[3,3] { { 0, 0, 0 }, { 0, 0, 0 }, { 0, 0, 0 }}; 
    }


}
