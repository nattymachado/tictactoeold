﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ButterflyBehaviourScript : MonoBehaviour {

    private Camera _camera;
    private float _directionX=1f;
    private float _directionY=-1f;
    private SpriteRenderer _sprite;

    public float speed = 0.5f;

    // Use this for initialization
    void Start () {

        Debug.Log("Initializing");

        _camera = Camera.main;
        _directionX = 1f;
        _directionY = -1f;
        _sprite = GetComponent<SpriteRenderer>();

        //transform.position = _camera.WorldToScreenPoint(new Vector3());


    }

    // Update is called once per frame
    void Update () {

        transform.position = new Vector3(transform.position.x + (speed * _directionX), transform.position.y + (speed * _directionY), 0f);

        Vector3 position = _camera.WorldToScreenPoint(transform.position);
        if ((position.y < 0))
        {
            _directionY = 1f;
            _sprite.color = new Color(transform.position.x, transform.position.y, 0.5f);
            Debug.Log(_sprite.color);
        } else if ((position.y > Screen.height))
        {
            _directionY = -1f;
            _sprite.color = new Color(transform.position.x, transform.position.y, 0.5f);
            Debug.Log(_sprite.color);
        }

        if ((position.x < 0))
        {
            _directionX = 1f;
            _sprite.color = new Color(transform.position.x, transform.position.y, 0.5f);
            Debug.Log(_sprite.color);
        }
        else if ((position.x > Screen.width))
        {
            _directionX = -1f;
            _sprite.color = new Color(transform.position.x, transform.position.y, 0.5f);
            Debug.Log(_sprite.color);
        }

        

        






    }
}
